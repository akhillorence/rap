import 'package:firebase_auth/firebase_auth.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class AuthServices {
  static final _firabaseAuth = FirebaseAuth.instance;

  static Future<String> signup(
      {required String email, required String password}) async {
    String res = "Something went wrong";

    try {
      UserCredential _cred = await _firabaseAuth.createUserWithEmailAndPassword(
          email: email, password: password);
      res = "Success";
    } catch (e) {
      res = e.toString();
    }
    return res;
  }

  static Future<String> login(
      {required String email, required String password}) async {
    String res = "Something went wrong";

    try {
      UserCredential _cred = await _firabaseAuth.signInWithEmailAndPassword(
          email: email, password: password);
      res = "Success";
    } catch (e) {
      res = e.toString();
    }

    return res;
  }
}
