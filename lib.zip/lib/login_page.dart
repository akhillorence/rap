import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:rap_trial/admin_login.dart';
import 'package:rap_trial/forgot_password.dart';
import 'package:rap_trial/player_profile.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:rap_trial/services/auth_services.dart';
import 'package:rap_trial/signup_page.dart';
import 'package:get/get.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:fluttertoast/fluttertoast.dart';

class MyLoginPage extends StatefulWidget {
  const MyLoginPage({super.key});

  @override
  State<MyLoginPage> createState() => _MyLoginPageState();
}

class _MyLoginPageState extends State<MyLoginPage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  _loginUser() async {
    _isLoading = true;
    String email = _usernameController.text.trim();
    String password = _passwordController.text.trim();
    String res = await AuthServices.login(email: email, password: password);
    _isLoading = false;

    if (res != "Success") {
      print(res);
      return;
    }
    try {
      await AuthServices.login(email: email, password: password);

      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => PlayerProfile()));
    } on FirebaseAuthException catch (error) {
      Fluttertoast.showToast(
          msg: "Password is incorrect",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 350,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/rap1.png'),
                      fit: BoxFit.fill)),
            )),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Container(
              height: 550,
              decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(40),
                      topLeft: Radius.circular(40))),
              child: Align(
                alignment: Alignment.center,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 25,
                    ),
                    Text(
                      'WELCOME',
                      maxLines: 3,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 45,
                          color: Colors.white70),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 40.0, right: 40.0),
                      child: Column(
                        children: [
                          SizedBox(
                            height: 65,
                          ),
                          SizedBox(
                            height: 50,
                            child: TextField(
                              controller: _usernameController,
                              style: TextStyle(fontSize: 20),
                              decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Colors.white,
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(40)),
                                      borderSide: BorderSide(
                                          color: Color.fromARGB(
                                              116, 188, 180, 180))),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(40)),
                                      borderSide: BorderSide(
                                          color: Color.fromARGB(
                                              116, 188, 180, 180))),
                                  hintText: "USERNAME",
                                  hintStyle: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w100,
                                      color:
                                          Color.fromARGB(116, 188, 180, 180))),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          SizedBox(
                            height: 50,
                            child: TextField(
                              controller: _passwordController,
                              obscureText: true,
                              style: TextStyle(fontSize: 20),
                              decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Colors.white,
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(40)),
                                      borderSide: BorderSide(
                                          color: Color.fromARGB(
                                              116, 188, 180, 180))),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(40)),
                                      borderSide: BorderSide(
                                          color: Color.fromARGB(
                                              116, 188, 180, 180))),
                                  hintText: "PASSWORD",
                                  hintStyle: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w100,
                                      color:
                                          Color.fromARGB(116, 188, 180, 180))),
                            ),
                          ),
                          Positioned(
                            right: 30,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            ForgotPassword()));
                              },
                              child: Text(
                                "Forgot Password ?",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Color.fromARGB(255, 99, 188, 92),
                                    decoration: TextDecoration.underline),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    SizedBox(
                      height: 50,
                      width: 150,
                      child: Container(
                          child: Column(children: [
                        ElevatedButton(
                            onPressed: () {
                              _loginUser();
                            },
                            style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.only(left: 40, right: 40),
                                backgroundColor:
                                    Color.fromARGB(255, 99, 188, 92)),
                            child: _isLoading
                                ? Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : Center(
                                    child: Text(
                                      "LOGIN",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                  )),
                      ])),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AdminLogin()));
                      },
                      child: Text(
                        "LOGIN AS ADMIN ",
                        style: TextStyle(
                            fontSize: 20,
                            color: Color.fromARGB(255, 99, 188, 92),
                            decoration: TextDecoration.underline),
                      ),
                    ),
                    Text(
                      "OR",
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignUpPage()));
                      },
                      child: Text(
                        "SIGNUP",
                        style: TextStyle(
                            fontSize: 20,
                            color: Color.fromARGB(255, 99, 188, 92),
                            decoration: TextDecoration.underline),
                      ),
                    )
                  ],
                ),
              )),
        ),
      ]),
    );
  }
}
